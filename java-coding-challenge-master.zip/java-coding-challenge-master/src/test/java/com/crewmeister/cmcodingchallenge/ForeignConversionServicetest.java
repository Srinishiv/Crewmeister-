package com.crewmeister.cmcodingchallenge;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.crewmeister.cmcodingchallenge.currency.CurrencyCountry;
import com.crewmeister.cmcodingchallenge.currency.CurrencyDailyConversionRates;
import com.crewmeister.cmcodingchallenge.currency.ForeignAmountConversion;
import com.fasterxml.jackson.core.JsonProcessingException;

// I have written 4 test cases for 4 User stories 
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class ForeignConversionServicetest {

	@Autowired
	TestRestTemplate testrestTemplate;
	
	//private static final double DELTA = 1e-15;
	// Test case for All currency with will date
	@Test
	public void testAllcureencyDate()throws JsonProcessingException,Exception
	{
		
		//ObjectMapper mapper = new ObjectMapper();
	 //	List<CurrencyDailyConversionRates> myObjects = mapper.readValue(CurrencyDailyConversionRates., mapper.getTypeFactory().constructCollectionType(List.class, CurrencyDailyConversionRates.class));
		
		ResponseEntity<CurrencyDailyConversionRates> result=(ResponseEntity<CurrencyDailyConversionRates>) testrestTemplate.getForEntity("/api/allavailablexchange",CurrencyDailyConversionRates.class.arrayType());
	    assertEquals(HttpStatus.OK,result.getStatusCode());
		
	}
	// Test case for checking Converted Amount 
	//Amount <0 will give error , Date validation .if we take date>31
	@Test
	public void testAmountConversion()throws JsonProcessingException,Exception
	{
		ResponseEntity<ForeignAmountConversion> result= (ResponseEntity<ForeignAmountConversion>) testrestTemplate.getForEntity("/api/convertamt/2010-06-11/120",ForeignAmountConversion.class.arrayType());
		assertEquals(HttpStatus.OK,result.getStatusCode());
	}
	
   // Checking for all Currency with corresponding Country	
	@Test
	public void testAllcurrecyCountry()throws JsonProcessingException,Exception
	{
		ResponseEntity<CurrencyCountry> result= (ResponseEntity<CurrencyCountry>) testrestTemplate.getForEntity("/api/allcurencycode",CurrencyCountry.class.arrayType());
		assertEquals(HttpStatus.OK,result.getStatusCode());
	}
	
	// Checking for all Currency with specified dates 
	@Test
	public void testcurrecyspecificDate()throws JsonProcessingException,Exception
	{
		ResponseEntity<CurrencyDailyConversionRates> result= (ResponseEntity<CurrencyDailyConversionRates>) testrestTemplate.getForEntity("/api/perdtavailablexchange/2017-03-14",CurrencyDailyConversionRates.class.arrayType());
		assertEquals(HttpStatus.OK,result.getStatusCode());
	}
	

}
