/**
 * 
 */
package com.crewmeister.cmcodingchallenge.currency;

/**
 * @author s.bhaumik
 *
 */

// This is the Bean class for All currency and Country

public class CurrencyCountry {
	
private String county;
private String currencyCountry;
/**
 * @param county
 * @param currencyCountry
 */
public CurrencyCountry(String county, String currencyCountry) {
	super();
	this.county = county;
	this.currencyCountry = currencyCountry;
}
/**
 * @return the county
 */
public String getCounty() {
	return county;
}
/**
 * @param county the county to set
 */
public void setCounty(String county) {
	this.county = county;
}
/**
 * @return the currencyCountry
 */
public String getCurrencyCountry() {
	return currencyCountry;
}
/**
 * @param currencyCountry the currencyCountry to set
 */
public void setCurrencyCountry(String currencyCountry) {
	this.currencyCountry = currencyCountry;
}


}
