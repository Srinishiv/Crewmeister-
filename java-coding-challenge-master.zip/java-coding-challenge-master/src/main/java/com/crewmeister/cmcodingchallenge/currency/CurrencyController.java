package com.crewmeister.cmcodingchallenge.currency;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@RestController()
@RequestMapping("/api")
public class CurrencyController {

	@Autowired
	private ForeignConversionService frservice;
    @GetMapping("/currencies")
    public ResponseEntity<ArrayList<CurrencyConversionRates>> getCurrencies() {
        ArrayList<CurrencyConversionRates> currencyConversionRates = new ArrayList<CurrencyConversionRates>();
    //    currencyConversionRates.add(new CurrencyConversionRates(2.5));

        return new ResponseEntity<ArrayList<CurrencyConversionRates>>(currencyConversionRates, HttpStatus.OK);
    }
 // Get all EUR-FX exchange rates at all available dates as a collection   
    
   @GetMapping("/allavailablexchange")   
    public static ResponseEntity<ArrayList<CurrencyDailyConversionRates>> getalldateExchangerate() {
	 //  public  ResponseEntity<HashMap<CurrencyConversionRates, List<CurrencyDailyConversionRates>>> getalldateExchangerate() {
       ArrayList<CurrencyDailyConversionRates> currencyAlldateConversion= new ArrayList<CurrencyDailyConversionRates>();
        currencyAlldateConversion=(ArrayList<CurrencyDailyConversionRates>) ForeignConversionService.getallDateConversionrate();
     //   CurrencyDailyConversionRates cd=(CurrencyDailyConversionRates) frservice.getallDateConversionrate();
    //    HashMap<CurrencyConversionRates, List<CurrencyDailyConversionRates>> cd= frservice.getallDateConversionrate();
     //   return new ResponseEntity<HashMap<CurrencyConversionRates,List<CurrencyDailyConversionRates>>>(cd,HttpStatus.OK);
     //   System.out.println("----"+currencyAlldateConversion.toString());
          return new ResponseEntity<ArrayList<CurrencyDailyConversionRates>>(currencyAlldateConversion, HttpStatus.OK);
          
    }
    

   // Get the EUR-FX exchange rate at particular day   
   
    @GetMapping("/perdtavailablexchange/{perdate}")
    public ResponseEntity<ArrayList<CurrencyDailyConversionRates>> getalldateExchangerate(@PathVariable @DateTimeFormat(pattern="yyyy-MM-dd") String perdate) {
       
  //Implementation Validation for DATE to take care about valid Date  at the  of Request
    	String arrd[]=perdate.split("-");
    	int dayv =Integer.parseInt(arrd[2]);
    	int monthv=Integer.parseInt(arrd[1]);
    	int yearv=Integer.parseInt(arrd[0]);
    	if(perdate.isBlank()|| dayv>31 || dayv<=0 || dayv==31 && (monthv==2 || monthv==4 || monthv==6 || monthv==9 ||monthv==11) || arrd[2].length()!=2 ||arrd[1].length()!=2 ||arrd[0].length()!=4 || (yearv % 4 == 0 && dayv>28)||(yearv % 4 != 0 && dayv>29))
    	{
    		throw new ForeignConversionException("this is not valid date"+perdate);
    	}
        return new ResponseEntity<ArrayList<CurrencyDailyConversionRates>>((ArrayList<CurrencyDailyConversionRates>) frservice.getparticularDateConversionrate(perdate), HttpStatus.OK);
    }
    
 // Get a list of all available currencies   
    
    @GetMapping("/allcurencycode")
    public ResponseEntity<ArrayList<CurrencyCountry>> getCurrencycode() {
        ArrayList<CurrencyCountry> currencyCode= new ArrayList<>(); 
        currencyCode= frservice.getCurrencyCountrycode();
        return new ResponseEntity<ArrayList<CurrencyCountry>>(currencyCode, HttpStatus.OK);
    }
    
    
  //  Get a foreign exchange amount for a given currency converted to EUR on a particular day 
    
    @GetMapping("/convertamt/{curdt}/{amouteuro}")
    public ResponseEntity<ArrayList<ForeignAmountConversion>> getAmountconversion(@PathVariable @DateTimeFormat(pattern="yyyy-MM-dd") String curdt,@PathVariable double amouteuro) {
        ArrayList<ForeignAmountConversion> currenconamt= new ArrayList<>(); 
  // Respose Validation for Request      
       String arrd[]=curdt.split("-");
    	int a =Integer.parseInt(arrd[2]);
    	int b=Integer.parseInt(arrd[1]);
    // I am just considering amount should not be less than 10	
        if(amouteuro<0 ) 
        {
        	throw new ForeignConversionException(amouteuro,"Amount should not be less than 10"+" ---> "+amouteuro);
        }
        if(curdt.isBlank()|| a>31 || a<=0 || a==31 && (b==2 || b==4 || b==6 || b==9 ||b==11) || arrd[2].length()!=2 ||arrd[1].length()!=2 ||arrd[0].length()!=4 )
    	{
    		throw new ForeignConversionException("this is not valid date"+curdt);
    	}
        
        currenconamt= frservice.getConvertedAmount(curdt, amouteuro);
        return new ResponseEntity<ArrayList<ForeignAmountConversion>>(currenconamt, HttpStatus.OK);
    }
}
