/**
 * 
 */
package com.crewmeister.cmcodingchallenge.currency;

/**
 * @author s.bhaumik
 *
 */
import javax.xml.parsers.DocumentBuilderFactory;  
import javax.xml.parsers.DocumentBuilder;  
import org.w3c.dom.Document;  
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;  
import org.w3c.dom.Element;  
import java.io.File;
import java.util.HashMap;
import java.util.Map.Entry;  

// This is an Utility class where I am creating Map List and arraylist of a Data to supply it in Service class 
public class ForeignConversionUtility  
{  

// Create a Map for collecting Country and Currency
	
public static HashMap<String, String> currencyOrder()
{
	HashMap<String, String> hpcur= new HashMap<>();	
	hpcur.put("AUD", "AUD");
	hpcur.put("BGN", "BGN");
	hpcur.put("BRL", "BRL");
	hpcur.put("CAD", "CAD");
	hpcur.put("CHF", "CHF");
	hpcur.put("CNY", "CNY");
	hpcur.put("CYP", "CYP");
	hpcur.put("CZK", "CZK");
	hpcur.put("DKK", "DKK");
	hpcur.put("EEK", "EEK");
	hpcur.put("GBP", "GBP");
	hpcur.put("GRD", "GRD");
	hpcur.put("HKD", "HKD");
	hpcur.put("HRK", "HRK");
	hpcur.put("HUF", "HUF");
	hpcur.put("IDR", "IDR");
	hpcur.put("ILS", "ILS");
	hpcur.put("INR", "INR");
	hpcur.put("ISK", "ISK");
	hpcur.put("JPY", "JPY");
	hpcur.put("KRW", "KRW");
	hpcur.put("LTL", "LTL");
	hpcur.put("LVL", "LVL");
	hpcur.put("MTL", "MTL");
	hpcur.put("MXN", "MXN");
	hpcur.put("MYR", "MYR");
	hpcur.put("NOK", "NOK");
	hpcur.put("NZD", "NZD");
	hpcur.put("PHP", "PHP");
	hpcur.put("PLN", "PLN");
	hpcur.put("ROL", "ROL");
	hpcur.put("RON", "RON");
	hpcur.put("RUB", "RUB");
	hpcur.put("SEK", "SEK");
	hpcur.put("SGD", "SGD");
	hpcur.put("SIT", "SGD");
	hpcur.put("SKK", "SKK");
	hpcur.put("THB", "THB");
	hpcur.put("TRL", "TRL");
	hpcur.put("TRY", "TRY");
	hpcur.put("USD", "USD");
	hpcur.put("ZAR", "ZAR");
	
	return hpcur;
}

//creating a HashMap(we can create TreeMap also) to hold Time period and Exchange rate value from Corresponding XML file

//public static void main(String argv[])   
public static HashMap<String, Double> collectTimecurency()  
	
{  
HashMap<String,Double> hpc =new HashMap<>();	
try   
{  
	HashMap<String, String> hpv= currencyOrder();
for(Entry<String, String> entry:hpv.entrySet())	
{
//creating a constructor of file class and parsing an XML file  
File file = new File("BBEX3.D."+entry.getValue()+".EUR.BB.AC.000.xml");  
//System.out.println("test doc"+"BBEX3.D."+entry.getValue()+".EUR.BB.AC.000.xml");
//an instance of factory that gives a document builder  
DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
//an instance of builder to parse the specified xml file  
DocumentBuilder db = dbf.newDocumentBuilder();  
Document doc = db.parse(file);  
doc.getDocumentElement().normalize();  
//System.out.println("Root element: " + doc.getDocumentElement().getNodeName());  
NodeList nodeList = doc.getElementsByTagName("bbk:Obs");  
// nodeList is not iterable, so we are using for loop  
for (int itr = 0; itr < nodeList.getLength(); itr++)   
{  
Node node = nodeList.item(itr);  
//System.out.println("\nNode Name :" + node.getNodeName());  
if (node.getNodeType() == Node.ELEMENT_NODE)   
{  
Element eElement = (Element) node;  
//System.out.println("Time period: "+ eElement.getAttribute("TIME_PERIOD"));  
if(eElement.getAttribute("OBS_VALUE").length()==0)
{
	hpc.put(eElement.getAttribute("TIME_PERIOD").concat(" "+entry.getValue()),0.0);
}
else

hpc.put(eElement.getAttribute("TIME_PERIOD").concat(" "+entry.getValue()), Double.valueOf(eElement.getAttribute("OBS_VALUE")));
}
} 
}
}   
catch (Exception e)   
{  
e.printStackTrace();  
}  
return hpc;
}  

// Collecting the all values in MAP value of Country with corresponding Currency

public static HashMap<String, String> collectTimeconv()  

{  
// creating a HashMap to hold Time period and Exchange rate value
	
	HashMap<String,String> hpc =new HashMap<>();
	String countryName="";
	String[] countryNamecut= {};	
try   
{  
  HashMap<String, String> hpv= currencyOrder();
  for(Entry<String, String> entry:hpv.entrySet())	
{
 File file = new File("BBEX3.D."+entry.getValue()+".EUR.BB.AC.000.xml");  
//an instance of factory that gives a document builder  
DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();  
//an instance of builder to parse the specified xml file  
DocumentBuilder db = dbf.newDocumentBuilder();  
Document doc = db.parse(file);  
doc.getDocumentElement().normalize();  
//System.out.println("Root element: " + doc.getDocumentElement().getNodeName());  
NodeList nodeList = doc.getElementsByTagName("bbk:Series");  
// nodeList is not iterable, so we are using for loop  
for (int itr = 0; itr < nodeList.getLength(); itr++)   
{  
Node node = nodeList.item(itr);  
//System.out.println("\nNode Name :" + node.getNodeName());  
if (node.getNodeType() == Node.ELEMENT_NODE)   
{  
Element eElement = (Element) node;  
//Optional<String> checkst=Optional.ofNullable(eElement.getAttribute("OBS_VALUE"));
countryName= eElement.getAttribute("BBK_TITLE_ENG")+ "/" ;
//System.out.println("country name is "+countryName);
countryNamecut=countryName.split("/");
//countryNamecut=countryName.split("..."+ "/"+"/");
hpc.put(entry.getValue(),countryNamecut[2]);
}
} 
}
}   
catch (Exception e)   
{  
e.printStackTrace();  
}  
return hpc;
}  

}  

