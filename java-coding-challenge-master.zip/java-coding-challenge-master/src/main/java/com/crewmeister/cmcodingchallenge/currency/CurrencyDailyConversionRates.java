/**
 * 
 */
package com.crewmeister.cmcodingchallenge.currency;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author s.bhaumik
 *
 */
// This is the  Bean class for all Currency in all Dates available with corresponding Exchangerates

public  class CurrencyDailyConversionRates {

	/**
	 * @param currenc
	 * @param timePeriod
	 * @param exchangeRates
	 */
	
	private String currency;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd", timezone="EST")
	private Date timePeriod;
	private double exchangeRates;

	/**
	 * @param timePeriod the timePeriod to set
	 */
	public void setTimePeriod(Date timePeriod) {
		this.timePeriod = timePeriod;
	}

	/**
	 * @return the timePeriod
	 */
	public Date getTimePeriod() {
		return timePeriod;
	}

	
	public CurrencyDailyConversionRates(String currency, Date timePeriod, double exchangeRates) {
		super();
		this.currency = currency;
		this.timePeriod = timePeriod;
		this.exchangeRates = exchangeRates;
	}

	/**
	 * @return the currenc
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currenc the currenc to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public CurrencyDailyConversionRates() {
		super();
	}

	
     /**
	 * @return the exchangeRates
	 */
	public double getExchangeRates() {
		return exchangeRates;
	}

	/**
	 * @param exchangeRates the exchangeRates to set
	 */
	public void setExchangeRates(double exchangeRates) {
		this.exchangeRates = exchangeRates;
	}
	
	@Override
	public String toString() {
		return "CurrencyDailyConversionRates [exchangeRates=" + exchangeRates + ", timePeriod=" + timePeriod
				+ ", currenc=" + currency + "]";
	}
	

}
