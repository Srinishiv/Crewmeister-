/**
 * 
 */
package com.crewmeister.cmcodingchallenge.currency;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;


/**
 * @author s.bhaumik
 *
 */
//This is one Exception class for handling the Request Validation Exception 

@ResponseStatus(HttpStatus.NOT_FOUND)
public class ForeignConversionException extends RuntimeException {
	

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


public ForeignConversionException (String msg)
{
	super(msg);
	
}


public ForeignConversionException (double damt,String ms)
{
	super(ms);
	
}

}
