/**
 * 
 */
package com.crewmeister.cmcodingchallenge.currency;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import org.springframework.stereotype.Service;

/**
 * @author s.bhaumik
 *
 */

// This is a main Service class which is responsible to execute the Business Logic based on the functionality

@Service
public class ForeignConversionService {
	static int i =0;
	public ForeignConversionUtility fronvUtil;
	private static HashMap<String, Double> cdailytimcr=ForeignConversionUtility.collectTimecurency();
	private static HashMap<String, String> cdailyOrdercur=ForeignConversionUtility.collectTimeconv();
	private static List<CurrencyDailyConversionRates> cdailyConverobj= new ArrayList<CurrencyDailyConversionRates>();
	
	 // Collect the Time period and exchange rate from HashMap(We can also use TreeMap) and add it into CurrencyDailyConversionRates	
static
	{
	//HashMap<String, Double> cdailytimcr=ForeignConversionUtility.collectTimecurency();
		for(Entry<String,Double> curdEntrytimecon:cdailytimcr.entrySet())
		{
    // String value Converting to Date and also Date makes compatable with JSON			
			
			String tpcur=curdEntrytimecon.getKey();
			//System.out.println("The concatinate string value"+tpcur);
			String[] finaltmcur=tpcur.split(" ");
			String dtd[]=finaltmcur[0].split("-");
			int incdt=Integer.valueOf(dtd[2])+1;
			String finaldtst=dtd[0]+"-"+dtd[1]+"-"+String.valueOf(incdt);
			Date date1 = null;
			try {
				date1 = new SimpleDateFormat("yyyy-MM-dd").parse(finaldtst);
				
			//	date1 = new SimpleDateFormat("yyyy-MM-dd").parse(finaltmcur[0]);
			//	date1.setTime( date1.getTime() + date1.getTimezoneOffset()*60*100);
				
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
			
			cdailyConverobj.add(new CurrencyDailyConversionRates(finaltmcur[1],date1,curdEntrytimecon.getValue()));
			
		}
		/*
		 * FileWriter myWriter; try { myWriter = new FileWriter("filename.txt");
		 * myWriter.write(cdailyConverobj.toString()); myWriter.close(); } catch
		 * (IOException e) { // TODO Auto-generated catch block e.printStackTrace(); } }
		 */
	}

// Get Currenc,Timestamp,ExchangeRate as an Object of CurrencyDailyConversionRates class .


	public static List<CurrencyDailyConversionRates> getallDateConversionrate()
	//public  HashMap<CurrencyConversionRates, List<CurrencyDailyConversionRates>> getallDateConversionrate()
	{
		//	cdailyConverobj1=(List<CurrencyDailyConversionRates>)cdailyConverobj.stream().collect(Collectors.toList());
		return cdailyConverobj;
		//return cdailytimcr1;
	}		    
		
	
	
	
// Get Currency and ExchangeRate for a particular date
	
   public List<CurrencyDailyConversionRates> getparticularDateConversionrate(String pardate)
   {
	   List<CurrencyDailyConversionRates> cdailyperdatecol= new ArrayList<CurrencyDailyConversionRates>();
	   for(CurrencyDailyConversionRates cdv:cdailyConverobj)
	   {
		// String value Converting to Date and also Date makes compatable with JSON		  
		   
		   String dtd[]=pardate.split("-");
			int incdt=Integer.valueOf(dtd[2])+1;
			String finaldtst=dtd[0]+"-"+dtd[1]+"-"+String.valueOf(incdt);
			Date date1 = null;
			try {
			    date1 = new SimpleDateFormat("yyyy-MM-dd").parse(finaldtst);
				} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		   if(cdv.getTimePeriod().compareTo(date1)==0)
		   {
			   cdailyperdatecol.add(new CurrencyDailyConversionRates(cdv.getCurrency(),cdv.getTimePeriod(),cdv.getExchangeRates()));
		   }
	   }
	   
	   return cdailyperdatecol ;
   }
   
 // Get All currency with respective Country List  
   
   public ArrayList<CurrencyCountry> getCurrencyCountrycode()
   {
	    List<CurrencyCountry> curcont=new ArrayList<>();
	    for(Entry<String,String> curent:cdailyOrdercur.entrySet())
	    {
	    	curcont.add(new CurrencyCountry(curent.getValue(),curent.getKey()));
	    }
	    return  (ArrayList<CurrencyCountry>) curcont;
   }
   
 // Euro Amount conversion to Corresponding Currency with a specific Date
   
   public ArrayList<ForeignAmountConversion> getConvertedAmount(String curdt,double curamt)
   {
	   List<ForeignAmountConversion> curconvAmount=new ArrayList<>();
	
	// String value Converting to Date and also Date makes compatable with JSON	
	   double finalcalValue=0.0;
	   double finaldblconvertedValue=0.0;
	   double curnconrt=0.0;
	   String curen="";
	   String dtd[]=curdt.split("-");
	   int incdt=Integer.valueOf(dtd[2])+1;
		String finaldtst=dtd[0]+"-"+dtd[1]+"-"+String.valueOf(incdt);
	   Date date1 = new Date();
	   try {
			date1 = new SimpleDateFormat("yyyy-MM-dd").parse(finaldtst);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	  
	   for(CurrencyDailyConversionRates cdv:cdailyConverobj)
	   {
		  if(cdv.getTimePeriod().compareTo(date1)==0)
		   {
			   finalcalValue=cdv.getExchangeRates() * curamt;
			   BigDecimal bd= new BigDecimal(finalcalValue).setScale(2,RoundingMode.HALF_UP);
			   finaldblconvertedValue=bd.doubleValue();
			   curen=cdv.getCurrency();
			   curnconrt=cdv.getExchangeRates();
			   curconvAmount.add(new ForeignAmountConversion(date1, curen, curnconrt, curamt, finaldblconvertedValue));
		   }
	   }
	   return (ArrayList<ForeignAmountConversion>) curconvAmount;
   }
   
   }
