package com.crewmeister.cmcodingchallenge.currency;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;

// This is a Bean class for calculating Euro Amount to the Correcponding Currency amount of a particular day

public class ForeignAmountConversion {
@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd", timezone="EST")
private Date currentdate;
private String currentCurrency;
private double currentcurrencValue;
private double currentAmount;
private double convertadeAmount;

/**
 * @param currentdate
 * @param currentCurrency
 * @param currentcurrencValue
 * @param currentAmount
 * @param convertadeAmount
 */
public ForeignAmountConversion(Date currentdate, String currentCurrency, double currentcurrencValue,
		double currentAmount, double convertadeAmount) {
	super();
	this.currentdate = currentdate;
	this.currentCurrency = currentCurrency;
	this.currentcurrencValue = currentcurrencValue;
	this.currentAmount = currentAmount;
	this.convertadeAmount = convertadeAmount;
}

/**
 * @return the currentcurrencValue
 */
public double getCurrentcurrencValue() {
	return currentcurrencValue;
}
/**
 * @param currentcurrencValue the currentcurrencValue to set
 */
public void setCurrentcurrencValue(double currentcurrencValue) {
	this.currentcurrencValue = currentcurrencValue;
}
/**
 * @return the currentdate
 */
public Date getCurrentdate() {
	return currentdate;
}
/**
 * @param currentdate the currentdate to set
 */
public void setCurrentdate(Date currentdate) {
	this.currentdate = currentdate;
}
/**
 * @return the currentCurrency
 */
public String getCurrentCurrency() {
	return currentCurrency;
}
/**
 * @param currentCurrency the currentCurrency to set
 */
public void setCurrentCurrency(String currentCurrency) {
	this.currentCurrency = currentCurrency;
}
/**
 * @return the currentAmount
 */
public double getCurrentAmount() {
	return currentAmount;
}
/**
 * @param currentAmount the currentAmount to set
 */
public void setCurrentAmount(double currentAmount) {
	this.currentAmount = currentAmount;
}
/**
 * @return the convertadeAmount
 */
public double getConvertadeAmount() {
	return convertadeAmount;
}
/**
 * @param convertadeAmount the convertadeAmount to set
 */
public void setConvertadeAmount(double convertadeAmount) {
	this.convertadeAmount = convertadeAmount;
}

@Override
public String toString() {
	return "ForeignAmountConversion [currentdate=" + currentdate + ", currentCurrency=" + currentCurrency
			+ ", currentcurrencValue=" + currentcurrencValue + ", currentAmount=" + currentAmount
			+ ", convertadeAmount=" + convertadeAmount + "]";
}


}
